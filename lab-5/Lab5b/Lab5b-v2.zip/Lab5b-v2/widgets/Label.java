package widgets;

public class Label extends Widget {
	// has a text string as data - which is provided at create time
	// width and height are determined from this
	// assume each character is 5 units wide and 10 units high
	
	// does not react to mouse events
	
	// provides methods to get text
	

}
