package widgets;

public class Button extends Widget implements Clickable {
	
	
	// has methods to get/set text
	
	
	// implements/overrides draw to draw a box at the correct position and size
	// and displays the text of the button
	
	
	// implement the onClick method to check if the click is within its bounds
	// and if so, invokes protected method handleClick
	
	
	
	protected void handleClick() {   // should we make this abstract?

	}
	
	
}
