package widgets;

import java.util.ArrayList;

public class Panel extends Widget {

	
	
	public void addWidget(Widget w, Location loc) {
		// add a child widget
		// position of lower left of child is at loc in Panel coordinates
		
	}
	
	// implements/overrides draw. Draws a box corresponding to its size and
	// calls draw on each child widget

	

}
