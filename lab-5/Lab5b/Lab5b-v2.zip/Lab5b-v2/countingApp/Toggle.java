package countingApp;

import display.Display;
import widgets.Button;

public class Toggle extends Button {

	
	
	// redefines draw so that it draws a circular outline 
	// (instead of the default rectangular outline of Button)
	// "position" of Toggle is defined as the lower left corner of the
	// box that would enclose the circle
	
	
	
	// Toggles its state on each click. 
	// Displays the text "Up" or "Down" accordingly
	

	// has a method to get its current state
	
	
}
