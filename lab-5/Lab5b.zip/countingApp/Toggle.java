package countingApp;

import widgets.Button;
import widgets.Clickable;

public class Toggle extends Button {
	// Maintains a state that corresponds to Up or Down
	// Intiial state is Up
	
	// redefines draw so that it draws a circular outline 
	// (instead of the default rectangular outline of Button)
	
	// "position" of Toggle is defined as the lower left corner of the
	// box that would enclose the circle
	
	// Toggles its state on each click. 
	// Displays the text "Up" or "Down" accordingly
	
	// has a method to get its current state
	
}
