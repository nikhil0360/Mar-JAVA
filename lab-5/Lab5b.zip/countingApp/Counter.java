package countingApp;

import widgets.Button;


public class Counter extends Button {
	// has a reference to an instance of Toggle button
	
	// Everytime it is clicked, it increments or decrements counter by 1
	// depending on state of the Toggle instance
	
	// Shows the current count as its text
	
}
