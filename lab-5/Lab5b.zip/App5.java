
public class App5 {

	public static void main(String[] args) {
		
		// create a Display object
		// assume there will be only Display object 
		

		// create instance of CountingApp, assigns Display instance to it
		// CountingApp reads first part of input and creates widgets
		
		
		// reads input - mouse clicks - and passes them on to Display
		
		
		
	}

}
