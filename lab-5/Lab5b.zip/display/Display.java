package display;

public class Display {

	void set(Panel p, int x0, int y0) {
		// add a Panel at location x0,y0
	
	}
	
	void redisplay() {
		// invokes draw of panel
		
	}
	
	void registerClickable(Clickable c) {
		// maintains list of Clickables that have been registered. These will
		// be notified when processClick is invoked
		
	}
	
	void processClick(int x, int y) {  // x,y in global coordinates of Display
		// passes on to all Clickables registerd
		
		// invokes redisplay after each click
	}
	
	
	// methods used by other classes to actually draw on the display
	public static void drawLine(int x0, int y0, int x1, int y1) {
		// draw a line from x0,y0, to x1,y1
		// for purposes of this exercise print to System.out:
		// Line from <x0>,<y0> to <x1>,<y1>
		 
	}
	
	public static void drawText(int x0, int y0, String s) {
		// display a string starting at position x0, y0
		// for purposes of this exercise, print to System.out:
		// Text at <x0>, <y0>: <input string s>
		
	}
	
	public static void drawCircle(int cx, int cy, int radius) {
		// draw a circle with given parameters
		// for purposes of this exercise, print to System.out:
		// Circle at <cx>,<cy> radius <radius>
		
	}
}
