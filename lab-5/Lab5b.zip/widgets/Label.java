package widgets;

public class Label extends Widget {  // does not react to mouse events
	// has a text string as data - which is provided at create time
	// width and height are determined from this
	// assume each character is 5 units wide and 10 units high
	
	// provides methods to get text
}
