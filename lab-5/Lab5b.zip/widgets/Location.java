package widgets;

class Location {
	// convenience class - encapsulates the pair x,y
	Location(int x, int y) {  
		
	}
	
}
